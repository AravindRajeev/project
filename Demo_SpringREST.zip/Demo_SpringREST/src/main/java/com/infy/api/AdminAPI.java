package com.infy.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.infy.model.Admin;
import com.infy.model.Employee;
import com.infy.service.AdminService;

@CrossOrigin
@RestController
@RequestMapping(value = "/infy")
public class AdminAPI {

	@Autowired
	private AdminService adminService;

	@GetMapping(value = "/getAdmin/{employeeId}")
	public ResponseEntity<Admin> getEmployeeDetails(@PathVariable Integer employeeId) throws Exception {
		try {
			Admin admin = adminService.getAdminData(employeeId);
			ResponseEntity<Admin> response = new ResponseEntity<Admin>(admin, HttpStatus.OK);
			return response;
		} catch (ResponseStatusException exception) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Error");
		}

	}

	@GetMapping(value = "/admins")
	public ResponseEntity<List<Employee>> getAllAdmins() throws Exception {
		List<Employee> employeeList = adminService.getAllAdmins();
		ResponseEntity<List<Employee>> response = new ResponseEntity<List<Employee>>(employeeList, HttpStatus.OK);
		return response;
	}
	

	@PostMapping(value = "/addAdmin")
	public ResponseEntity<String> addEmployee(@RequestBody Admin admin) throws Exception {

		String username=adminService.addAdminData(admin);
		String message;
		if(username!=null) {
			message = "Admin added successfully";
		}
		else {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Error");
		}
		ResponseEntity<String> response = new ResponseEntity<String>(message, HttpStatus.CREATED);
		return response;
	}

	@PostMapping(value = "/updateAdmin")
	public ResponseEntity<String> updateEmployee(@RequestBody Admin admin) throws Exception {

		String username=adminService.updateAdminData(admin);
		String message;
		if(username!=null) {
			message="Admin updated successfully";
			ResponseEntity<String> response = new ResponseEntity<String>(message,HttpStatus.CREATED);
			return response;
		}
		else {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Error");
		}
		
	}
}
