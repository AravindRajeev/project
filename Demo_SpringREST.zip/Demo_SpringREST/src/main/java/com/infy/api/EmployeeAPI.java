package com.infy.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.infy.model.Employee;

import com.infy.service.EmployeeService;

@CrossOrigin
@RestController
@RequestMapping(value="/infy")
public class EmployeeAPI {
	
	@Autowired
	private EmployeeService employeeService;
	
	
	@GetMapping(value = "/employees")
	public ResponseEntity<List<Employee>> getAllEmployeeDetails() throws Exception {
		List<Employee> employeeList = employeeService.getAllEmployeeDetails();
		ResponseEntity<List<Employee>> response = new ResponseEntity<List<Employee>>(employeeList, HttpStatus.OK);
		return response;
	}
	
	
	@GetMapping(value = "/employee/{employeeId}")
	public ResponseEntity<Employee> getEmployeeDetails(@PathVariable Integer employeeId)  throws Exception  {
		try {
			Employee employee = employeeService.getEmployee(employeeId);
			ResponseEntity<Employee> response = new ResponseEntity<Employee>(employee, HttpStatus.OK);
			return response;
		}
		catch (Exception exception) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Error");
		}
		
	}
	
	
    @PostMapping(value = "/addEmployee")
	public ResponseEntity<String> addEmployee(@RequestBody Employee employee) throws Exception  {
		employeeService.addEmployee(employee);
		String successMessage = "Employee added successfully";
		ResponseEntity<String> response = new ResponseEntity<String>(successMessage, HttpStatus.CREATED);
		return response;
	}
    
    @PostMapping(value = "/updateEmployee")
	public ResponseEntity<String> updateEmployee(@RequestBody Employee employee)  throws Exception {
    	System.out.println(employee.getEmployeeId());
    	employeeService.updateEmployee(employee);
		String successMessage = "Employee updated successfully.";
		ResponseEntity<String> response = new ResponseEntity<String>(successMessage, HttpStatus.OK);
		return response;
	}
    
	@DeleteMapping(value = "/deleteEmployee/{employeeId}")
	public ResponseEntity<String> deleteEmployee(@PathVariable Integer employeeId) throws Exception  {
		employeeService.deleteEmployee(employeeId);
		String successMessage = "Employee deleted succssfully";
		ResponseEntity<String> response = new ResponseEntity<String>(successMessage, HttpStatus.OK);
		return response;
	}
}
