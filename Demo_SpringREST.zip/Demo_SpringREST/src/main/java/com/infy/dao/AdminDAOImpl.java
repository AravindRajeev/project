package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.infy.entity.AdminEntity;
import com.infy.entity.EmployeeEntity;
import com.infy.model.Admin;
import com.infy.model.Employee;

@Repository(value = "adminDAO")
public class AdminDAOImpl implements AdminDAO {

	@PersistenceContext
	private EntityManager entity;

	@Override
	public String addAdminData(Admin admin) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("admin" + admin.getEmployee().getEmployeeId());
		EmployeeEntity employeeEntity = entity.find(EmployeeEntity.class, admin.getEmployee().getEmployeeId());
		System.out.println("employ" + employeeEntity.getEmployeeName());
		if (employeeEntity != null) {
			AdminEntity adminEntity = new AdminEntity();
			adminEntity.setEmployeeEntity(employeeEntity);
			adminEntity.setPassword(admin.getPassword());
			entity.persist(adminEntity);
			return adminEntity.getEmployeeEntity().getEmployeeName();
		}
		return null;
	}

	@Override
	public Admin getAdminData(Integer employeeId) throws Exception {
		// TODO Auto-generated method stub
		Admin admin = new Admin();
		Query query = entity
				.createQuery("select admin from AdminEntity admin where admin.employeeEntity.employeeId=?1");
		query.setParameter(1, employeeId);
		List<AdminEntity> adminEntityList = query.getResultList();
		if (adminEntityList.size() != 0) {
			AdminEntity adminEntity = adminEntityList.get(0);
			EmployeeEntity employeeEntity = adminEntity.getEmployeeEntity();
			Employee employee = new Employee();
			employee.setDob(employeeEntity.getDob());
			employee.setEmailId(employeeEntity.getEmailId());
			employee.setEmployeeId(employeeEntity.getEmployeeId());
			employee.setGender(employeeEntity.getGender());
			employee.setUnit(employeeEntity.getUnit());
			employee.setEmployeeName(employeeEntity.getEmployeeName());
			admin.setEmployee(employee);
			admin.setPassword(adminEntity.getPassword());
			return admin;

		}
		return null;
	}

	@Override
	public String updateAdminData(Admin admin) throws Exception {
		// TODO Auto-generated method stub
		AdminEntity adminEntity = new AdminEntity();
		Query query = entity
				.createQuery("select admin from AdminEntity admin where admin.employeeEntity.employeeId=?1");
		query.setParameter(1, admin.getEmployee().getEmployeeId());
		List<AdminEntity> adminEntityList = query.getResultList();
		if (adminEntityList.size() != 0) {
			adminEntity=adminEntityList.get(0);
			adminEntity.setPassword(admin.getPassword());
			return adminEntity.getEmployeeEntity().getEmployeeName();

		}

		return null;

	}

	@Override
	public List<Employee> getAllAdmins() throws Exception {
		Query query = entity.createQuery("select admin.employeeEntity.employeeId from AdminEntity admin");
		List<Integer> empIdList = query.getResultList();
		Query queryEmp = entity.createQuery("select emp from EmployeeEntity emp where emp.employeeId in ?1");
		queryEmp.setParameter(1, empIdList);
		List<EmployeeEntity> eList = queryEmp.getResultList();
		List<Employee> empList = new ArrayList<>();
		Employee employee;
		for (EmployeeEntity employeeEntity : eList) {
			employee = new Employee();
			employee.setEmailId(employeeEntity.getEmailId());
			employee.setEmployeeId(employeeEntity.getEmployeeId());
			employee.setEmployeeName(employeeEntity.getEmployeeName());
			employee.setUnit(employeeEntity.getUnit());
			employee.setDob(employeeEntity.getDob());
			employee.setGender(employeeEntity.getGender());
			empList.add(employee);
		}
		return empList;
	}

	@Override
	public Employee validateAdmin(Admin admin) throws Exception {
		// TODO Auto-generated method stub
		Admin adminCheck=getAdminData(admin.getEmployee().getEmployeeId());
		if(adminCheck!=null) {
			if(admin.getPassword().equals(adminCheck.getPassword())) {
				return adminCheck.getEmployee();
			}
			else {
				return null;
			}
		}
		return null;
	}

	

}
