package com.infy.dao;

import java.util.ArrayList;
import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;

import org.springframework.stereotype.Repository;

import com.infy.entity.EmployeeEntity;
import com.infy.model.Employee;

@Repository(value = "employeeDAO")
public class EmployeeDAOImpl implements EmployeeDAO {
	@PersistenceContext
	private EntityManager entity;
	
	public Integer addEmployee(Employee employee) throws Exception{
		EmployeeEntity employeeEntity=new EmployeeEntity();
		employeeEntity.setEmailId(employee.getEmailId());
		employeeEntity.setEmployeeId(employee.getEmployeeId());
		employeeEntity.setEmployeeName(employee.getEmployeeName());
		employeeEntity.setUnit(employee.getUnit());
		employeeEntity.setDob(employee.getDob());
		employeeEntity.setGender(employee.getGender());
		entity.persist(employeeEntity);
		return employeeEntity.getEmployeeId();
	}
	public Employee getEmployee(Integer employeeId) throws Exception{
		Employee employee=new Employee();
		EmployeeEntity emp=entity.find(EmployeeEntity.class, employeeId);
		if(emp != null) {
			employee.setEmailId(emp.getEmailId());
			employee.setEmployeeId(emp.getEmployeeId());
			employee.setEmployeeName(emp.getEmployeeName());
			employee.setUnit(emp.getUnit());
			employee.setDob(emp.getDob());
			employee.setGender(emp.getGender());
			return employee;
		}
		else {
			return null;
		}
	}
	public Integer updateEmployee(Employee employee) throws Exception{
		EmployeeEntity employeeEntity= new EmployeeEntity();
		employeeEntity=entity.find(EmployeeEntity.class, employee.getEmployeeId());
		if(employeeEntity!=null) {
			employeeEntity.setEmailId(employee.getEmailId());
			employeeEntity.setUnit(employee.getUnit());
			employeeEntity.setEmployeeName(employee.getEmployeeName());
			return employeeEntity.getEmployeeId();
		}
		return -1;
		
	}
	public Integer deleteEmployee(Integer employeeId) throws Exception{
		EmployeeEntity employeeEntity= new EmployeeEntity();
		employeeEntity=entity.find(EmployeeEntity.class, employeeId);
		
		if(employeeEntity!=null) {
			entity.remove(employeeEntity);
			return employeeEntity.getEmployeeId();
		}
		return -1;
		
		
	}
	public List<Employee> getAllEmployeeDetails(){
		Query query=entity.createQuery("select emp from EmployeeEntity emp");
		List<EmployeeEntity> eList=query.getResultList();
		List<Employee> empList= new ArrayList<>();
		Employee employee;
		for (EmployeeEntity employeeEntity : eList) {
			employee=new Employee();
			employee.setEmailId(employeeEntity.getEmailId());
			employee.setEmployeeId(employeeEntity.getEmployeeId());
			employee.setEmployeeName(employeeEntity.getEmployeeName());
			employee.setUnit(employeeEntity.getUnit());
			employee.setDob(employeeEntity.getDob());
			employee.setGender(employeeEntity.getGender());
			empList.add(employee);
		}
		return empList;
		
	}

	

}