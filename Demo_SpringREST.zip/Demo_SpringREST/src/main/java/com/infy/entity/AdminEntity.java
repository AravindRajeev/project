package com.infy.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="admindata")
public class AdminEntity {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
//	@Column(name="employeeid")
//	private Integer employeeId;
	private String username;
	private String password;
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="employeeid")
	private EmployeeEntity employeeEntity;
	
	
	
	public EmployeeEntity getEmployeeEntity() {
		return employeeEntity;
	}
	public void setEmployeeEntity(EmployeeEntity employeeEntity) {
		this.employeeEntity = employeeEntity;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
