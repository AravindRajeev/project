package com.infy.model;
import java.sql.Date;

public class Employee {

	private Integer employeeId;
	private String employeeName;
	private String emailId;
	private String unit;
	private Date dob;
	private char gender;
	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public Employee() {


	}
	
	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Employee(Integer employeeId, String emailId, String name) {
		super();
		this.employeeId = employeeId;
		this.emailId = emailId;
		this.employeeName = name;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer customerId) {
		this.employeeId = customerId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	

	
}
