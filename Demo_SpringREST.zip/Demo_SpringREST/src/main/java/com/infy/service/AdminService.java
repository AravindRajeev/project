package com.infy.service;

import java.util.List;

import com.infy.model.Admin;
import com.infy.model.Employee;

public interface AdminService {
	public String addAdminData(Admin admin) throws Exception;
	public Admin getAdminData(Integer employeeId) throws Exception;
	public String updateAdminData(Admin admin) throws Exception;
	public List<Employee> getAllAdmins() throws Exception;
	public Employee validateAdmin(Admin admin) throws Exception;
}
