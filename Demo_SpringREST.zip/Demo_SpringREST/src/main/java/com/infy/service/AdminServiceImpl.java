package com.infy.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.AdminDAO;
import com.infy.model.Admin;
import com.infy.model.Employee;

@Service(value = "adminService")
@Transactional
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDAO adminDAO;

	@Override
	public String addAdminData(Admin admin) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(admin.getEmployee().getEmployeeId());
		if (adminDAO.getAdminData(admin.getEmployee().getEmployeeId()) != null) {
			throw new Exception("Service.ADMIN_ALREADY_EXISTS");
		}

		return adminDAO.addAdminData(admin);
	}

	@Override
	public Admin getAdminData(Integer employeeId) throws Exception {
		// TODO Auto-generated method stub
		Admin admin = adminDAO.getAdminData(employeeId);
		if (admin == null) {
			throw new Exception("Service.ADMIN_UNAVAILABLE");
		}
		return admin;
	}

	@Override
	public String updateAdminData(Admin admin) throws Exception {
		if (adminDAO.getAdminData(admin.getEmployee().getEmployeeId()) != null) {
			
			return adminDAO.updateAdminData(admin);
			
		}
		else {
			throw new Exception("Service.ADMIN_DOESNOT_EXISTS");
		}
		
	}

	@Override
	public List<Employee> getAllAdmins() throws Exception {
		// TODO Auto-generated method stub
		List<Employee> employeeList = adminDAO.getAllAdmins();
		if (employeeList == null) {
			throw new Exception("Service.NO_ADMIN_AVAILABLE");
		}
		return employeeList;
		
	}

	@Override
	public Employee validateAdmin(Admin admin) throws Exception {
		// TODO Auto-generated method stub
		Employee employee=adminDAO.validateAdmin(admin);
		if(employee!=null) {
			return employee;
		}
		else {
			throw new Exception("Service.INCORRECT USERNAME OR PASSWORD");
		}
		
	}

}
