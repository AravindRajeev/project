package com.infy.service;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.infy.dao.EmployeeDAO;
import com.infy.model.Employee;



@RunWith(SpringRunner.class)
@SpringBootTest
public class EmployeeServiceImplTest {
	
	@Mock 
	private EmployeeDAO employeeDao;
	
	@InjectMocks 
	private EmployeeService employeeService = new EmployeeServiceImpl();

	@Rule
	public ExpectedException expectedException = ExpectedException.none();
	
	@Test
	 public void addEmployeeTestValid() throws Exception{
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.addEmployee(employee)).thenReturn(1067600);
		Integer empId=employeeService.addEmployee(employee);
		Assert.assertEquals(new Integer(1067600), empId);
		
	}
	@Test
	public void updateEmployeeTestValid() throws Exception{
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.getEmployee(employee.getEmployeeId())).thenReturn(employee);
		when(employeeDao.updateEmployee(employee)).thenReturn(employee.getEmployeeId());
		Integer empId=employeeService.updateEmployee(employee);
		Assert.assertEquals(new Integer(1067600), empId);
	}
	@Test
	public void deleteEmployeeTestValid() throws Exception{
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.getEmployee(employee.getEmployeeId())).thenReturn(employee);
		when(employeeDao.deleteEmployee(employee.getEmployeeId())).thenReturn(employee.getEmployeeId());
		Integer empId=employeeService.deleteEmployee(employee.getEmployeeId());
		Assert.assertEquals(new Integer(1067600), empId);
	}
	@Test
	 public void addEmployeeTestInValid() throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("Service.EMPLOYEE_ALREADY_EXISTS");
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.getEmployee(employee.getEmployeeId())).thenReturn(employee);
		Integer empId=employeeService.addEmployee(employee);
		
		
	}
	@Test
	 public void updateEmployeeTestInValid() throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("Service.EMPLOYEE_UNAVAILABLE");
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.getEmployee(employee.getEmployeeId())).thenReturn(null);
		Integer empId=employeeService.updateEmployee(employee);
		
		
	}
	@Test
	 public void deleteEmployeeTestInValid() throws Exception{
		expectedException.expect(Exception.class);
		expectedException.expectMessage("Service.EMPLOYEE_UNAVAILABLE");
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.getEmployee(employee.getEmployeeId())).thenReturn(null);
		Integer empId=employeeService.deleteEmployee(employee.getEmployeeId());
		
		
	}
}
