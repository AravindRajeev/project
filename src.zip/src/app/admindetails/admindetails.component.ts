import { Component, OnInit } from '@angular/core';
import { AdmindetailsService } from './admindetails.service';

@Component({
  selector: 'app-admindetails',
  templateUrl: './admindetails.component.html',
  styleUrls: ['./admindetails.component.css']
})
export class AdmindetailsComponent implements OnInit {
  error: String;
  columnDefs = [
    { headerName: 'EmployeeId', field: 'employeeId', suppressMovable: true, sortable: true, filter: "agNumberColumnFilter" },
    {
      headerName: 'Employee Name', field: 'employeeName', suppressMovable: true, sortable: true, filter: "agTextColumnFilter",
      filterParams: {
        filterOptions: ["contains", "notContains"],
        debounceMs: 0,
        caseSensitive: false,
        suppressAndOrCondition: true,
        clearButton: true
      }
    },
    {
      headerName: 'Email Id', field: 'emailId', suppressMovable: true, sortable: true, filter: "agTextColumnFilter",
      filterParams: {
        filterOptions: ["contains", "notContains"],
        debounceMs: 0,
        caseSensitive: false,
        suppressAndOrCondition: true,
        clearButton: true
      }
    },
    {
      headerName: 'DOB', field: 'dob', suppressMovable: true, width: 120, sortable: true, cellRenderer: (data) => {
        return data.value ? (new Date(data.value)).toLocaleDateString('en-GB') : '';
      },
      filter: "agDateColumnFilter",
      filterParams: {
        comparator: function (filterLocalDateAtMidnight, cellValue) {
          var event = new Date(filterLocalDateAtMidnight);
          let date = JSON.stringify(event)
          console.log(date)
          date = date.slice(1, 11)
          var dateAsString = cellValue;
          var dateParts = dateAsString.split("-");
          var cellDate = dateParts[0] + "-" + (dateParts[1]) + "-" + (dateParts[2] - 1)
          console.log(cellDate, date)
          if (cellDate === date) {
            return 0;
          }
          if (cellDate < date) {
            return -1;
          }
          if (cellDate > date) {
            return 1;
          }
        },
        suppressAndOrCondition: true,
        clearButton: true
      }
    },
    {
      headerName: 'Gender', field: 'gender', suppressMovable: true, width: 120, sortable: true, filter: "agTextColumnFilter",
      filterParams: {
        filterOptions: ["contains", "notContains"],
        debounceMs: 0,
        caseSensitive: false,
        suppressAndOrCondition: true,
        clearButton: true
      }
    },
    {
      headerName: 'Unit', field: 'unit', suppressMovable: true, width: 120, sortable: true, filter: "agTextColumnFilter",
      filterParams: {
        filterOptions: ["contains", "notContains"],
        debounceMs: 0,
        caseSensitive: false,
        suppressAndOrCondition: true,
        clearButton: true
      }
    },


  ];

  rowData = [


  ];
  constructor(private adminDetailService: AdmindetailsService) { }

  public getAdmins(): any {
    this.adminDetailService.getAdmins().subscribe(
      response => { this.rowData = response; },
      error => this.error = error
    )

  }
  ngOnInit() {
    this.getAdmins();
  }

}
