import { Component, OnInit } from '@angular/core';
import { AdmindetailsService } from './admindetails.service';

@Component({
  selector: 'app-admindetails',
  templateUrl: './admindetails.component.html',
  styleUrls: ['./admindetails.component.css']
})
export class AdmindetailsComponent implements OnInit {
  error: String;
  columnDefs = [
    { headerName: 'EmployeeId', field: 'employeeId', suppressMovable: true, width: 120, sortable: true },
    { headerName: 'Employee Name', field: 'employeeName', suppressMovable: true, sortable: true },
    { headerName: 'Email Id', field: 'emailId', suppressMovable: true, sortable: true },
    {
      headerName: 'DOB', field: 'dob', suppressMovable: true, width: 110, sortable: true, cellRenderer: (data) => {
        return data.value ? (new Date(data.value)).toLocaleDateString('en-GB') : '';
      }
    },
    { headerName: 'Gender', field: 'gender', suppressMovable: true, width: 100, sortable: true },
    { headerName: 'Unit', field: 'unit', suppressMovable: true, width: 100, sortable: true },


  ];

  rowData = [


  ];
  constructor(private adminDetailService: AdmindetailsService) { }

  public getAdmins(): any {
    this.adminDetailService.getAdmins().subscribe(
      response => { this.rowData = response; },
      error => this.error = error
    )

  }
  ngOnInit() {
    this.getAdmins();
  }

}
