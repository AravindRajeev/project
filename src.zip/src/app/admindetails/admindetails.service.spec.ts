import { TestBed } from '@angular/core/testing';

import { AdmindetailsService } from './admindetails.service';

describe('AdmindetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdmindetailsService = TestBed.get(AdmindetailsService);
    expect(service).toBeTruthy();
  });
});
