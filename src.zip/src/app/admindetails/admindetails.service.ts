import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import { Employee } from '../employeedetails/Employee';

@Injectable({
  providedIn: 'root'
})
export class AdmindetailsService {
  url:string;
  constructor(private http:HttpClient) { }
  
  getAdmins():Observable<Employee[]>{
    this.url='http://localhost:3557/infy/admins';
    return this.http.get<Employee[]>(this.url);
  }
}
