import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule,HttpClient } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule} from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';
import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';
import { UpdaterendererComponent } from './employeedetails/updaterenderer/updaterenderer.component';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { EmployeedetailspopupComponent } from './employeedetails/employeedetailspopup/employeedetailspopup.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule, MatInputModule, MatSnackBarModule, MatDatepickerModule, MatNativeDateModule, MatRadioModule, MAT_DATE_LOCALE, MatIconModule, MatToolbarModule, MatSidenavModule, MatCardModule } from '@angular/material';
import { MessagepopupComponent } from './messagepopup/messagepopup.component';
import { SignupComponent } from './signup/signup.component';
import { ChangecredentialsComponent } from './changecredentials/changecredentials.component';
import { AdmindetailsComponent } from './admindetails/admindetails.component';
import {MatListModule} from '@angular/material/list';
import {TranslateModule, TranslateLoader} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import { AuthGuard } from './auth.guard';
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    EmployeedetailsComponent,
    UpdaterendererComponent,
    EmployeedetailspopupComponent,
    MessagepopupComponent,
    SignupComponent,
    ChangecredentialsComponent,
    AdmindetailsComponent,
    
  

    
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    AgGridModule.withComponents([AppComponent]),
    HttpClientModule,
    ReactiveFormsModule,
    MatDialogModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSnackBarModule,
    MatDatepickerModule, 
    MatNativeDateModule,
    MatRadioModule,
    MatIconModule,
    MatToolbarModule,
    MatListModule,
    MatSidenavModule,
    MatCardModule,
    TranslateModule.forRoot({
      defaultLanguage: 'en',
      loader: {
          provide: TranslateLoader,
          useFactory: HttpLoaderFactory,
          deps: [HttpClient]
      }
  })

   
    
    
  ],
  providers: [ AuthGuard,{ provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} },{provide: MAT_DATE_LOCALE, useValue: 'en-US'},MatCardModule,MatDatepickerModule,MatRadioModule,MatSidenavModule,MatIconModule,MatToolbarModule,MatListModule],entryComponents:[UpdaterendererComponent,EmployeedetailspopupComponent,MessagepopupComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
