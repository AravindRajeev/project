import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '../../../node_modules/@angular/forms';
import { Admin } from '../login/Admin';
import { ChangecredentialsService } from './changecredentials.service';
import { MatSnackBar } from '../../../node_modules/@angular/material';

@Component({
  selector: 'app-changecredentials',
  templateUrl: './changecredentials.component.html',
  styleUrls: ['./changecredentials.component.css']
})
export class ChangecredentialsComponent implements OnInit {
  changeCredentialForm: FormGroup
  oldPassword: String;
  oldUsername: String;
  errorMessage: String;
  successMessage:String;
  employeeId:Number;
  constructor(private snackbar:MatSnackBar,private formBuilder: FormBuilder, private changeCredentialService: ChangecredentialsService) { }
  admin: Admin = new Admin();
  getAdmin() {
    this.changeCredentialService.getAdminData(this.changeCredentialForm.controls.employeeId.value).subscribe(
      response => { this.admin = response, this.changeCredentials() },
      error => {this.errorMessage = error.error.message;this.snackBarAction()}
    )
  }
  openSnackBar(message: string, action: string) {
    this.snackbar.open(message, action, {
      duration: 3000,
    });
  }
  snackBarAction(){
    if(this.errorMessage=="Error" || this.errorMessage=="Service.ADMIN_UNAVAILABLE"){
      this.openSnackBar("Invalid Credentials", "Close")
      this.errorMessage=null
      this.ngOnInit();
    }
    else{
      this.openSnackBar("Credentials updated successfully", "Close")
      this.successMessage=null
      this.ngOnInit();
    }
  }
  changeCredentials() {
    
    if (this.admin.employee.employeeId == this.changeCredentialForm.controls.employeeId.value && this.admin.password == this.changeCredentialForm.controls.oldPassword.value) {
      this.employeeId = this.changeCredentialForm.controls.employeeId.value;
      this.admin.employee.employeeId=this.employeeId;
      this.admin.password = this.changeCredentialForm.controls.newPassword.value;
      this.changeCredentialService.updateAdminData(this.admin).subscribe(
        response=>{this.successMessage=response;this.snackBarAction()},
        error=>{this.errorMessage=error.error.message;this.snackBarAction()}
      )
    }
    else{
      this.errorMessage="Error";
      this.snackBarAction();
    }

  }
  ngOnInit() {
    this.changeCredentialForm = this.formBuilder.group({
      employeeId: ['', Validators.required],
      oldPassword: ['', Validators.required],
      newPassword: ['', Validators.required],
    })
  }

}
