import { TestBed } from '@angular/core/testing';

import { ChangecredentialsService } from './changecredentials.service';

describe('ChangecredentialsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ChangecredentialsService = TestBed.get(ChangecredentialsService);
    expect(service).toBeTruthy();
  });
});
