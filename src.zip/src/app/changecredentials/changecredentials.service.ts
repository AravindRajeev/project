import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Admin } from '../login/Admin';
import { Observable } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChangecredentialsService {

  url:string;
  constructor(private http:HttpClient) { }
  updateAdminData(admin:Admin):Observable<String>{
    this.url='http://localhost:3557/infy/updateAdmin';
    return this.http.post<String>(this.url,admin);
  }
  getAdminData(employeeId:Number):Observable<Admin>{
    this.url='http://localhost:3557/infy/getAdmin/'+employeeId;
    return this.http.get<Admin>(this.url);
  }
}
