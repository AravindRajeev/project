import { Component, OnInit } from '@angular/core';
import { Employee } from './Employee';
import { EmployeedetailsService } from './employeedetails.service';
import { UpdaterendererComponent } from './updaterenderer/updaterenderer.component';
import { EmployeedetailspopupComponent } from './employeedetailspopup/employeedetailspopup.component';
import { MatDialog } from '@angular/material/dialog';
import { RowNode, Column, GridOptions, GridApi } from 'ag-grid-community';
import { MatSnackBar } from '@angular/material';
import { MessagepopupComponent } from '../messagepopup/messagepopup.component';
import {TranslateService} from '@ngx-translate/core';


@Component({
  selector: 'app-employeedetails',
  templateUrl: './employeedetails.component.html',
  styleUrls: ['./employeedetails.component.css']
})
export class EmployeedetailsComponent implements OnInit {

  private frameworkComponents;
  error: String;
  employee: Employee = new Employee();
  message: String;
  employeeIdToDelete: Number
  gridAPI: any;
  columnAPI: any;
  oldData: any;
  newData: any
  method: string;
  flag: boolean = false;
  columnDefs = [
    {
      headerName: 'EmployeeId', field: 'employeeId',width:120, suppressMovable: true, sortable: true, filter: "agNumberColumnFilter", filterParams: {
        suppressAndOrCondition: true,
        clearButton: true
      }
    },
    {
      headerName: 'Employee Name', field: 'employeeName', suppressMovable: true, sortable: true,
      filter: "agTextColumnFilter",
      filterParams: {
        filterOptions: ["contains", "notContains"],
        debounceMs: 0,
        caseSensitive: false,
        suppressAndOrCondition: true,
        clearButton: true
      }
    },
    { headerName: 'Email Id', field: 'emailId', suppressMovable: true, sortable: true,filter: "agTextColumnFilter",
    filterParams: {
      filterOptions: ["contains", "notContains"],
      debounceMs: 0,
      caseSensitive: false,
      suppressAndOrCondition: true,
      clearButton: true} },
    {
      headerName: 'DOB', field: 'dob',width:90, suppressMovable: true, sortable: true, cellRenderer: (data) => {
        return data.value ? (new Date(data.value)).toLocaleDateString('en-GB') : '';
      },
      filter: "agDateColumnFilter",
      filterParams: {
        comparator: function (filterLocalDateAtMidnight, cellValue) {
          var event = new Date(filterLocalDateAtMidnight);
          let date = JSON.stringify(event)
          console.log(date)
          date = date.slice(1, 11)
          var dateAsString = cellValue;
          var dateParts = dateAsString.split("-");
          var cellDate = dateParts[0] + "-" + (dateParts[1]) + "-" + (dateParts[2] - 1)
          console.log(cellDate, date)
          if (cellDate === date) {
            return 0;
          }
          if (cellDate < date) {
            return -1;
          }
          if (cellDate > date) {
            return 1;
          }
        },
        suppressAndOrCondition: true,
        clearButton: true
      }
    },
    {
      headerName: 'Gender', field: 'gender', suppressMovable: true, width: 90, sortable: true, filter: "agTextColumnFilter",
      filterParams: {
        filterOptions: ["contains", "notContains"],
        debounceMs: 0,
        caseSensitive: false,
        suppressAndOrCondition: true,
        clearButton: true
      }
    },
    {
      headerName: 'Unit', field: 'unit', suppressMovable: true, width: 90, sortable: true, filter: "agTextColumnFilter",
      filterParams: {
        filterOptions: ["contains", "notContains"],
        debounceMs: 0,
        caseSensitive: false,
        suppressAndOrCondition: true,
        clearButton: true
      }
    },
    {
      headerName: 'Actions', field: 'update', width: 158, suppressMovable: true, cellRendererFramework: UpdaterendererComponent, cellRendererParams: {
        onClick: this.onAction.bind(this),
        label: 'Click'
      }
    },

  ];

  rowData = [


  ];
  employeeIdPass: string;
  public gridOptions: GridOptions;
  constructor(public translate:TranslateService,private employeeService: EmployeedetailsService, public dialog: MatDialog, private snackBar: MatSnackBar) {
    this.gridOptions = <GridOptions>{
      columnDefs: this.columnDefs,
      rowData: this.rowData,

    }
    translate.addLangs(['en','fr']);
    translate.setDefaultLang('en');
    const browserLang = 'fr'
  }
  
  onAdd(): void {
    this.gridOptions = <GridOptions>{
      columnDefs: this.columnDefs,
      rowData: this.rowData,

    }
    const dialogRef = this.dialog.open(EmployeedetailspopupComponent, {
      width: '490px', height: '575px',

    });

    dialogRef.afterClosed().subscribe(result => {
      this.newData = result;
      if (result) {
        this.addEmployee();
      }

    });
  }

  public getEmployee(): any {
    this.employeeService.getEmployee().subscribe(
      response => { this.rowData = response; },
      error => this.error = error
    )

  }

  ngOnInit() {
    this.getEmployee()
  }

  onGridReady(params) {
    this.gridAPI = params.api;
    this.columnAPI = params.columnApi;

  }
  onAction(data: any) {
    this.gridOptions = <GridOptions>{
      columnDefs: this.columnDefs,
      rowData: this.rowData,

    }
    if (data.action == "update") {
      this.oldData = data;
      const dialogRef = this.dialog.open(EmployeedetailspopupComponent, {
        width: '490px', height: '575px',
        data: data

      });
      dialogRef.afterClosed().subscribe(result => {
        this.newData = result;
        if (result) {
          if (JSON.stringify(this.oldData.rowData) != JSON.stringify(this.newData)) {
            const dialogRef = this.dialog.open(MessagepopupComponent, {
              width: '230px', height: '155px',
              data: { message: "update" }

            });

            dialogRef.afterClosed().subscribe(result => {
              if (result == true) {
                this.updateEmployee();
              }

            });
          }
          else {
            this.openSnackBar("Employee details remains the same", "Close")
          }
        }


      });
    }
    if (data.action == "delete") {
      this.employeeIdToDelete = data.rowData.employeeId;
      // if (confirm('Are you sure! Do you want to delete')) {
      //   this.deleteEmployee();
      // }
      const dialogRef = this.dialog.open(MessagepopupComponent, {
        width: '230px', height: '155px',
        data: { message: "delete" }

      });

      dialogRef.afterClosed().subscribe(result => {
        if (result == true) {
          this.deleteEmployee();
        }

      });
    }

  }


  deleteEmployee() {
    this.employeeService.deleteEmployee(this.employeeIdToDelete).subscribe(
      response => this.message = response,
      error => this.error = error
    )
    for (var i = 0; i < this.rowData.length; i++) {
      if (this.rowData[i].employeeId == this.employeeIdToDelete) {
        this.rowData.splice(i, 1);
      }
    }
    this.gridAPI.setRowData(this.rowData)
    console.log(this.rowData)
    this.method = "deleted"
    this.openSnackBar("Employee details " + this.method + " successfully", "Close")

  }

  updateEmployee() {

    this.employee.setEmailId(this.newData.emailId);
    this.employee.setEmployeeId(this.newData.employeeId);
    this.employee.setEmployeeName(this.newData.employeeName);
    this.employee.setUnit(this.newData.unit);
    this.employeeService.updateEmployee(this.employee).subscribe(
      response => this.message = response,
      error => this.error = error
    );
    this.method = "updated"
    for (var i = 0; i < this.rowData.length; i++) {
      if (this.rowData[i].employeeId == this.oldData.rowData.employeeId) {
        this.rowData[i].emailId = this.newData.emailId;
        this.rowData[i].employeeName = this.newData.employeeName;
        this.rowData[i].unit = this.newData.unit;
      }
    }
    console.log(this.rowData)
    this.gridAPI.setRowData(this.rowData)
    this.openSnackBar("Employee details " + this.method + " successfully", "Close")




  }
  addEmployee() {
    this.employee.setEmployeeId(this.newData.employeeId);
    this.employee.setEmployeeName(this.newData.employeeName);
    this.employee.setUnit(this.newData.unit);
    this.employee.setEmailId(this.newData.emailId);
    this.employee.setDob(this.newData.dob)
    this.employee.setGender(this.newData.gender)
    this.employeeService.addEmployee(this.employee).subscribe(
      response => this.message = response,
      error => this.error = error
    );
    this.method = "added"
    if (this.rowData.length == 0) {
      this.rowData.push(this.newData);
      this.gridAPI.setRowData(this.rowData)
      this.openSnackBar("Employee details " + this.method + " successfully", "Close")
    }
    else {
      for (let a of this.rowData) {
        if (a.employeeId != this.newData.employeeId) {
          console.log(a.employeeId)
          this.flag = true;
        }
        else {
          this.flag = false;
          break;
        }
      }
      if (this.flag == true) {
        this.rowData.push(this.newData);
        this.gridAPI.setRowData(this.rowData)
        this.openSnackBar("Employee details " + this.method + " successfully", "Close")
      }
      else {
        this.openSnackBar("Employee Id already exists", "Close")
      }
    }




  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }

}
