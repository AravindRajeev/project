import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { Employee } from '../Employee';
import { MatSnackBar } from '@angular/material';
import {TranslateService} from '@ngx-translate/core';
@Component({
  selector: 'app-employeedetailspopup',
  templateUrl: './employeedetailspopup.component.html',
  styleUrls: ['./employeedetailspopup.component.css']
})
export class EmployeedetailspopupComponent implements OnInit {
  message:String;
  error:String;
  employeeForm: FormGroup;
  employee:Employee=new Employee();
  empId:string;
  empName:string;
  emaId:string;
  un:string;
  res:any;
  dob:Date;
  gender:String;
  updateEmpID:String
  gEmployee:Employee=new Employee();
  method:string;
  value:string;
  tomorrow = new Date(); 

  

  constructor(public translate:TranslateService,private formBuilder:FormBuilder, public dialogRef:MatDialogRef<EmployeedetailspopupComponent>,
  @Inject(MAT_DIALOG_DATA) public data:any,public dialog: MatDialog,private snackBar: MatSnackBar) {
    dialogRef.disableClose = true;
    this.tomorrow.setDate(this.tomorrow.getDate());
    translate.addLangs(['en','fr']);
    translate.setDefaultLang('en');
    const browserLang = 'fr'
   }

  ngOnInit() {
    
    if(this.data==null){
      this.empId='';
      this.empName='';
      this.emaId='';
      this.un='';
      this.dob=null;
      this.gender='';
      this.updateEmpID="no"
    }
    else{
      console.log(this.data.rowData)
      this.empId=this.data.rowData.employeeId;
      this.empName=this.data.rowData.employeeName;
      this.emaId=this.data.rowData.emailId
      this.un=this.data.rowData.unit
      this.dob=this.data.rowData.dob
      this.gender=this.data.rowData.gender
      this.updateEmpID="yes"
    }
    this.employeeForm=this.formBuilder.group({
      employeeId:[this.empId,Validators.required],
      employeeName:[this.empName,Validators.required],
      emailId:[this.emaId,Validators.required],
      unit:[this.un,Validators.required],
      dob:[this.dob,Validators.required],
      gender:[this.gender,Validators.required]
    })
  }

  submit() {
    if(this.data==null){
        this.method="added"
      }
      else{
        this.method="updated"
      }
      console.log(this.employeeForm.value.dob)
      this.dialogRef.close(this.employeeForm.value);
    }

  close() {
      this.dialogRef.close();
  }

}


