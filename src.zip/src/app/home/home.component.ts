import { Component, OnInit } from '@angular/core';
import { MessagepopupComponent } from '../messagepopup/messagepopup.component';
import { MatDialog } from '@angular/material';
import { Router } from '../../../node_modules/@angular/router';
import {TranslateService} from '@ngx-translate/core';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  route:any;
  
  constructor(public translate:TranslateService,public dialog: MatDialog,private router: Router) { 
    translate.addLangs(['en','fr']);
    translate.setDefaultLang('en');
    const browserLang = 'fr'
  }
  ngOnInit() {
  }
  
 openDialog(){
  const dialogRef = this.dialog.open(MessagepopupComponent, {
    width: '230px', height: '152px',
    data: { message: "logout" }

  });

  dialogRef.afterClosed().subscribe(result => {
    if (result == true) {
      sessionStorage.clear();
      this.router.navigate(['']);
    }

  });
 }

}
