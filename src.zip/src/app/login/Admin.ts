import { Employee } from '../employeedetails/Employee';

export class Admin{
    employee:Employee;
    password: String;


    public getEmployee() {
        return this.employee
    }
    public setEmployee(employee:Employee){
        this.employee=employee;
    }
    public getPassword() {
        return this.password
    }
    public setPassword(password:String){
        this.password=password;
    }
}