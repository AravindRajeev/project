import { Employee } from '../employeedetails/Employee';

export class Admin{
    employee:Employee;
    username: String;
    password: String;


    public getEmployee() {
        return this.employee
    }
    public setEmployee(employee:Employee){
        this.employee=employee;
    }
    public getUsername() {
        return this.username
    }
    public setUsername(username:String){
        this.username=username;
    }
    public getPassword() {
        return this.password
    }
    public setPassword(password:String){
        this.password=password;
    }
}