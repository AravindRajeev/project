import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from './login.service';
import { Admin } from './Admin';
import { MatSnackBar } from '../../../node_modules/@angular/material';
import { MissingTranslationStrategy } from '../../../node_modules/@angular/compiler/src/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  employeeId:Number
  password: String;
  errorMessage: String = "Incorrect username or password";
  success: String = 'no';
  errorCond: boolean;
  admin: Admin = new Admin();
  error: string;
  isSignUp: string;
  isLogin: string = "yes";
  successMessage:String
  constructor(public translate:TranslateService,private formBuilder: FormBuilder, private loginService: LoginService,private snackBar: MatSnackBar) { 
    translate.addLangs(['en','fr']);
    translate.setDefaultLang('en');
    const browserLang = translate.getBrowserLang();
    translate.use(browserLang.match(/en|fr/)?browserLang:'en')
  }

  public login() {
    if (this.employeeId == this.admin.employee.employeeId && this.password == this.admin.password) {
      this.success = 'yes';
      this.isLogin = "no"
    
      this.errorCond = false;
    }
    else{
      console.log(this.error)
      this.success = 'no';
      this.isLogin = "yes"
   
      this.errorCond = true;

    }
  }
  public getAdminData() {
    this.employeeId=this.loginForm.controls.employeeId.value;
    this.password = this.loginForm.controls.password.value;
    this.loginService.getAdminData(this.employeeId).subscribe(
      response => { this.admin = response; this.login() },
      error => {this.error = error;this.login()}
    )


  }

  

  ngOnInit() {

    this.loginForm = this.formBuilder.group({
      employeeId:['', Validators.required],
      password: ['', Validators.required]
    })

  }

}
