import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from './login.service';
import { Admin } from './Admin';
import { MatSnackBar } from '../../../node_modules/@angular/material';
import { MissingTranslationStrategy } from '../../../node_modules/@angular/compiler/src/core';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '../../../node_modules/@angular/router';
import { Employee } from '../employeedetails/Employee';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  employeeId: Number
  password: String;
  errorMessage: String = "Incorrect username or password";
  success: String = 'no';
  errorCond: boolean;
  admin: Admin = new Admin();
  employee:Employee=new Employee();
  error: string;
  isSignUp: string;
  isLogged: string = "true";
  successMessage: String
  constructor(public router: Router, public translate: TranslateService, private formBuilder: FormBuilder, private loginService: LoginService, private snackBar: MatSnackBar) {
    translate.addLangs(['en', 'fr']);
    translate.setDefaultLang('en');
    const browserLang = translate.getBrowserLang();
    translate.use(browserLang.match(/en|fr/) ? browserLang : 'en')
  }

  public login() {
    if (this.error) {
      this.errorCond = true;
      this.error = null;

    }
    else{
      sessionStorage.setItem('employeeId',this.isLogged)
      sessionStorage.setItem('employee',JSON.stringify(this.employee));
      this.router.navigate(['home']);
      this.errorCond = false;
      
    }


  }
  public validateAdmin() {
    console.log(this.loginForm.controls.employeeId.value);
    this.employee.employeeId=this.loginForm.controls.employeeId.value;
    this.admin.employee=this.employee;
    this.admin.password=this.loginForm.controls.password.value;
    this.loginService.validateAdmin(this.admin).subscribe(
      response => { this.employee = response; this.login() },
      error => { this.error = error.error.message; this.login() }
    )


  }



  ngOnInit() {

    this.loginForm = this.formBuilder.group({
      employeeId: ['', Validators.required],
      password: ['', Validators.required]
    })

  }

}
