import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './Admin';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Employee } from '../employeedetails/Employee';





@Injectable({
  providedIn: 'root'
})
export class LoginService {
  url:string;
  constructor(private http:HttpClient) { }
  validateAdmin(Admin:Admin):Observable<Employee>{
    this.url='http://localhost:3557/infy/validateAdmin';
    return this.http.post<Employee>(this.url,Admin);
  }
  
}
