import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './Admin';
import { HttpClient } from '../../../node_modules/@angular/common/http';





@Injectable({
  providedIn: 'root'
})
export class LoginService {
  url:string;
  constructor(private http:HttpClient) { }
  getAdminData(employeeId:Number):Observable<Admin>{
    this.url='http://localhost:3557/infy/getAdmin/'+employeeId;
    return this.http.get<Admin>(this.url);
  }
  
}
