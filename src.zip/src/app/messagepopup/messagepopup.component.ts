import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-messagepopup',
  templateUrl: './messagepopup.component.html',
  styleUrls: ['./messagepopup.component.css']
})
export class MessagepopupComponent implements OnInit {
  message: string = this.data.message
  constructor(public dialogRef: MatDialogRef<MessagepopupComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;
  }

  ngOnInit() {

  }
  closeDialog() {
    this.dialogRef.close();
  }

}
