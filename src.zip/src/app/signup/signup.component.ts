import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { Admin } from '../login/Admin';
import { SignupService } from './signup.service';
import { MatSnackBar } from '../../../node_modules/@angular/material';
import { Employee } from '../employeedetails/Employee';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signUpForm: FormGroup;
  admin: Admin = new Admin();
  successMessage: String;
  errorMessage: String;
  employee: Employee;
  error: String;
  employeeId: Number;
  constructor(private formBuilder: FormBuilder, private signupService: SignupService, private snackbar: MatSnackBar) { }

  signUp() {
    this.admin.employee = this.employee;
    this.signupService.addAdminData(this.admin).subscribe(
      response => { this.successMessage = response; this.snackBarAction(); },
      error => { this.errorMessage = error.error.message; this.snackBarAction(); }
    )

  }
  public getEmployee(): any {
    this.employeeId = this.signUpForm.controls.employeeId.value;
    this.admin.password = this.signUpForm.controls.password.value;
    this.signupService.getEmployee(this.employeeId).subscribe(
      response => { this.employee = response; this.signUp() },
      error => this.error = error
    )

  }
  snackBarAction() {

    if (this.errorMessage == "Error") {
      this.openSnackBar("Employee does not exist", "Close")
      this.errorMessage = null
      this.ngOnInit();

    }
    if (this.errorMessage == "Service.ADMIN_ALREADY_EXISTS") {
      this.openSnackBar("Admin already exists", "Close")
      this.errorMessage = null
      this.ngOnInit();
    }
    else {
      this.openSnackBar("Admin added successfully", "Close")
      this.successMessage = null;
      this.ngOnInit();

    }
  }
  openSnackBar(message: string, action: string) {
    this.snackbar.open(message, action, {
      duration: 3000,
    });
  }
  ngOnInit() {

    this.signUpForm = this.formBuilder.group({
      employeeId: ['', Validators.required],
      password: ['', Validators.required],
    })
  }

}
