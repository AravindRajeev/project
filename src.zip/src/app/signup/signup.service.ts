import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Admin } from '../login/Admin';
import { Observable } from '../../../node_modules/rxjs';
import { Employee } from '../employeedetails/Employee';

@Injectable({
  providedIn: 'root'
})
export class SignupService {
  url:string;
  constructor(private http:HttpClient) { }
  addAdminData(admin:Admin):Observable<String>{
    this.url='http://localhost:3557/infy/addAdmin';
    return this.http.post<String>(this.url,admin);
  }
  getEmployee(employeeId:Number):Observable<Employee>{
    this.url='http://localhost:3557/infy/employee/'+employeeId;
    return this.http.get<Employee>(this.url);
  }
}
